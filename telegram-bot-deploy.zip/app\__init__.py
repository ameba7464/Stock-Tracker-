"""Telegram Bot приложение для селлеров Wildberries."""

__version__ = "1.0.1"  # CI/CD test deployment
