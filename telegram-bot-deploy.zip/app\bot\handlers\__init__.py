"""Инициализация обработчиков."""
from . import start, registration, menu, api_key, profile

__all__ = ["start", "registration", "menu", "api_key", "profile"]
