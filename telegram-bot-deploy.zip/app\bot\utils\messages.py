"""Шаблоны сообщений с чистым минималистичным дизайном."""
from dataclasses import dataclass
from typing import Optional
from datetime import datetime


@dataclass
class UserStatus:
    """Статус пользователя для отображения."""
    has_api_key: bool = False
    has_table: bool = False


@dataclass 
class UserProfile:
    """Данные профиля пользователя."""
    name: str = ""
    email: str = ""
    phone: str = ""


class Messages:
    """Централизованные шаблоны сообщений бота.
    
    Используем чистый минималистичный дизайн без громоздких Unicode-рамок.
    """
    
    # ═══════════════════════════════════════════════════
    # ПРИВЕТСТВИЯ
    # ═══════════════════════════════════════════════════
    
    @staticmethod
    def welcome_new_user() -> str:
        """Приветствие для нового пользователя."""
        return (
            "<b>Что это?</b>\n"
            "Stock Tracker — это персональный бизнес-ассистент для селлеров Wildberries, работающий прямо в Telegram. Сервис автоматически собирает все ключевые данные о ваших товарах и складах, превращая их в удобную Google Таблицу, которая обновляется каждый день без вашего участия.\n\n"
            "📝 <b>Шаг 1/3</b> — Как тебя зовут?"
        )
    
    @staticmethod
    def welcome_returning_user(name: str, status: UserStatus) -> str:
        """Приветствие для возвращающегося пользователя."""
        api_icon = "✅" if status.has_api_key else "❌"
        table_icon = "✅" if status.has_table else "⏳"
        
        return (
            f"🎯 <b>Stock Tracker</b>\n\n"
            f"👋 С возвращением, <b>{name}</b>!\n\n"
            f"{api_icon} API: {'Подключён' if status.has_api_key else 'Не подключён'}\n"
            f"{table_icon} Таблица: {'Готова' if status.has_table else 'Не создана'}\n\n"
            f"👇 Выберите действие:"
        )
    
    # ═══════════════════════════════════════════════════
    # РЕГИСТРАЦИЯ
    # ═══════════════════════════════════════════════════
    
    @staticmethod
    def registration_step_name(step: int = 1) -> str:
        """Шаг регистрации: запрос имени."""
        return (
            f"📝 <b>Регистрация</b> • Шаг {step}/3\n\n"
            "Как тебя зовут?\n\n"
            "<i>Введи имя или никнейм</i>"
        )
    
    @staticmethod
    def registration_step_email(name: str, step: int = 2) -> str:
        """Шаг регистрации: запрос email."""
        return (
            f"📝 <b>Регистрация</b> • Шаг {step}/3\n\n"
            f"Отлично, <b>{name}</b>!\n\n"
            "Теперь введи email:"
        )
    
    @staticmethod
    def registration_step_phone(step: int = 3) -> str:
        """Шаг регистрации: запрос телефона."""
        return (
            f"📝 <b>Регистрация</b> • Шаг {step}/3\n\n"
            "Последний шаг — номер телефона.\n\n"
            "📱 Нажми кнопку ниже или введи вручную\n\n"
            "<i>Формат: +79991234567</i>"
        )
    
    @staticmethod
    def registration_complete(name: str) -> str:
        """Регистрация завершена."""
        return (
            f"🎉 <b>Готово!</b>\n\n"
            f"Добро пожаловать, <b>{name}</b>!\n\n"
            "Теперь подключи API ключ Wildberries, "
            "чтобы получить свою таблицу."
        )
    
    # ═══════════════════════════════════════════════════
    # API КЛЮЧ
    # ═══════════════════════════════════════════════════
    
    @staticmethod
    def api_key_instructions() -> str:
        """Инструкция по получению API ключа."""
        return (
            "🔑 <b>Подключение Wildberries</b>\n\n"
            "Для работы нужен API ключ из личного кабинета.\n\n"
            "<b>Как получить:</b>\n"
            "1. Открой <a href='https://seller.wildberries.ru'>seller.wildberries.ru</a>\n"
            "2. Настройки → Доступ к API\n"
            "3. Создай ключ с правами:\n"
            "   • Аналитика\n"
            "   • Статистика\n"
            "4. Скопируй и отправь сюда\n\n"
            "📝 <i>Отправь ключ одним сообщением</i>"
        )
    
    @staticmethod
    def api_key_validating() -> str:
        """Проверка API ключа."""
        return (
            "⏳ <b>Проверяю ключ...</b>\n\n"
            "Подключаюсь к Wildberries API."
        )
    
    @staticmethod
    def api_key_success() -> str:
        """API ключ успешно сохранен."""
        return (
            "✅ <b>API ключ сохранён!</b>\n\n"
            "Теперь можешь создать свою таблицу."
        )
    
    @staticmethod
    def api_key_error() -> str:
        """Ошибка проверки API ключа."""
        return (
            "❌ <b>Не удалось проверить ключ</b>\n\n"
            "Возможные причины:\n"
            "• Неверный формат\n"
            "• Ключ деактивирован\n"
            "• Нет прав «Аналитика»\n\n"
            "Проверь ключ в ЛК WB и попробуй снова.\n\n"
            "<i>Для отмены: /start</i>"
        )
    
    # ═══════════════════════════════════════════════════
    # ТАБЛИЦА
    # ═══════════════════════════════════════════════════
    
    @staticmethod
    def table_generating() -> str:
        """Генерация таблицы."""
        return (
            "⏳ <b>Создаю таблицу...</b>\n\n"
            "• Получаю данные из WB\n"
            "• Формирую отчёт\n"
            "• Настраиваю доступ\n\n"
            "<i>Это займёт 1-2 минуты</i>"
        )
    
    @staticmethod
    def table_ready(sheet_url: str, is_new: bool = True) -> str:
        """Таблица готова."""
        return (
            f"✅ <b>Таблица готова!</b>\n\n"
            f"📊 <a href='{sheet_url}'>Открыть Google Таблицу</a>\n\n"
            "• Обновляется автоматически\n"
            "• Можно редактировать"
        )
    
    @staticmethod
    def table_error() -> str:
        """Ошибка создания таблицы."""
        return (
            "❌ <b>Не удалось создать таблицу</b>\n\n"
            "Возможные причины:\n"
            "• Проблема с Google API\n"
            "• Временные сбои WB\n\n"
            "Попробуй позже или обратись в поддержку."
        )
    
    # ═══════════════════════════════════════════════════
    # ИНФОРМАЦИЯ
    # ═══════════════════════════════════════════════════
    
    @staticmethod
    def main_menu(name: str, status: UserStatus) -> str:
        """Компактное меню для возврата (без полного приветствия)."""
        api_icon = "✅" if status.has_api_key else "❌"
        table_icon = "✅" if status.has_table else "⏳"
        
        return (
            f"🎯 <b>Stock Tracker</b>\n\n"
            f"{api_icon} API: {'Подключён' if status.has_api_key else 'Не подключён'}\n"
            f"{table_icon} Таблица: {'Готова' if status.has_table else 'Не создана'}\n\n"
            f"👇 Выберите действие:"
        )
    
    @staticmethod
    def about() -> str:
        """О сервисе."""
        return (
            "🎯 <b>Stock Tracker</b>\n\n"
            "Инструмент для селлеров Wildberries.\n\n"
            "<b>Возможности:</b>\n"
            "• Аналитика остатков на складах\n"
            "• Автоматическое обновление данных\n"
            "• Удобные Google Таблицы\n"
            "• Статистика по регионам\n\n"
            "👨‍💻 Разработано с ❤️"
        )
    
    @staticmethod
    def help_message() -> str:
        """Справка."""
        return (
            "💬 <b>Помощь</b>\n\n"
            "<b>Частые вопросы:</b>\n\n"
            "❓ <b>Где взять API ключ?</b>\n"
            "→ seller.wildberries.ru → Настройки → API\n\n"
            "❓ <b>Как часто обновляются данные?</b>\n"
            "→ Автоматически каждый день\n\n"
            "❓ <b>Могу редактировать таблицу?</b>\n"
            "→ Да, это твоя копия\n\n"
            "📧 Вопросы → администратору"
        )
    
    # ═══════════════════════════════════════════════════
    # ОШИБКИ
    # ═══════════════════════════════════════════════════
    
    @staticmethod
    def error_invalid_name() -> str:
        """Ошибка: неверное имя."""
        return (
            "❌ Имя должно быть от 2 до 50 символов.\n\n"
            "Попробуй ещё раз:"
        )
    
    @staticmethod
    def error_invalid_email() -> str:
        """Ошибка: неверный email."""
        return (
            "❌ Проверь формат email.\n"
            "Например: name@mail.ru\n\n"
            "Попробуй ещё раз:"
        )
    
    @staticmethod
    def error_invalid_phone() -> str:
        """Ошибка: неверный телефон."""
        return (
            "❌ Введи 10-15 цифр.\n"
            "Например: +79991234567\n\n"
            "Попробуй ещё раз:"
        )
    
    @staticmethod
    def error_general() -> str:
        """Общая ошибка."""
        return (
            "❌ Произошла ошибка.\n\n"
            "Попробуй позже или напиши в поддержку.\n"
            "Команда /start вернёт в начало."
        )
    
    @staticmethod
    def error_api_key_invalid() -> str:
        """Ошибка: неверный формат API ключа."""
        return (
            "❌ Ключ слишком короткий.\n\n"
            "API ключ WB обычно длиннее 100 символов.\n"
            "Проверь и отправь снова."
        )
    
    # ═══════════════════════════════════════════════════
    # НАСТРОЙКИ
    # ═══════════════════════════════════════════════════
    
    @staticmethod
    def settings_menu() -> str:
        """Меню настроек."""
        return (
            "⚙️ <b>Настройки</b>\n\n"
            "Управление аккаунтом и подключением.\n\n"
            "Выберите раздел:"
        )
    
    @staticmethod
    def settings_profile(profile: UserProfile) -> str:
        """Меню профиля с текущими данными."""
        return (
            "👤 <b>Профиль</b>\n\n"
            "Ваши данные:\n"
            f"• Имя: <b>{profile.name}</b>\n"
            f"• Email: <b>{profile.email}</b>\n"
            f"• Телефон: <b>{profile.phone}</b>\n\n"
            "Нажмите на поле, чтобы изменить:"
        )
    
    @staticmethod
    def settings_api(has_key: bool, added_date: Optional[datetime] = None) -> str:
        """Меню API ключа."""
        if has_key:
            status = "🟢 Активен"
            date_text = ""
            if added_date:
                date_text = f"\n📅 Добавлен: {added_date.strftime('%d.%m.%Y')}"
            return (
                "🔑 <b>API ключ</b>\n\n"
                f"Статус: {status}{date_text}\n\n"
                "Выберите действие:"
            )
        else:
            return (
                "🔑 <b>API ключ</b>\n\n"
                "Статус: 🔴 Не добавлен\n\n"
                "Добавьте ключ для работы с Wildberries:"
            )
    
    @staticmethod
    def api_check_status_checking() -> str:
        """Проверка статуса API ключа."""
        return "🔍 Проверяю ключ..."
    
    @staticmethod
    def api_check_status_active() -> str:
        """API ключ активен."""
        return (
            "🟢 <b>Ключ активен!</b>\n\n"
            "Подключение к Wildberries работает корректно."
        )
    
    @staticmethod
    def api_check_status_invalid() -> str:
        """API ключ недействителен."""
        return (
            "🔴 <b>Ключ недействителен</b>\n\n"
            "Возможные причины:\n"
            "• Ключ деактивирован в ЛК WB\n"
            "• Истёк срок действия\n"
            "• Нет необходимых прав\n\n"
            "Обновите ключ в настройках."
        )
    
    @staticmethod
    def api_delete_confirm() -> str:
        """Подтверждение удаления API ключа."""
        return (
            "🗑 <b>Удаление API ключа</b>\n\n"
            "Вы уверены?\n\n"
            "После удаления нужно будет добавить ключ заново "
            "для работы с таблицей."
        )
    
    @staticmethod
    def api_deleted() -> str:
        """API ключ удалён."""
        return (
            "✅ <b>API ключ удалён</b>\n\n"
            "Добавьте новый ключ для продолжения работы."
        )
    
    # ═══════════════════════════════════════════════════
    # РЕДАКТИРОВАНИЕ ПРОФИЛЯ
    # ═══════════════════════════════════════════════════
    
    @staticmethod
    def edit_name_prompt(current_name: str) -> str:
        """Запрос нового имени."""
        return (
            "✏️ <b>Изменение имени</b>\n\n"
            f"Текущее имя: <b>{current_name}</b>\n\n"
            "Введите новое имя (2-50 символов):"
        )
    
    @staticmethod
    def edit_email_prompt(current_email: str) -> str:
        """Запрос нового email."""
        return (
            "📧 <b>Изменение email</b>\n\n"
            f"Текущий email: <b>{current_email}</b>\n\n"
            "Введите новый email:"
        )
    
    @staticmethod
    def edit_phone_prompt(current_phone: str) -> str:
        """Запрос нового телефона."""
        return (
            "📱 <b>Изменение телефона</b>\n\n"
            f"Текущий телефон: <b>{current_phone}</b>\n\n"
            "Введите новый номер (формат: +79991234567):"
        )
    
    @staticmethod
    def edit_success(field: str, new_value: str) -> str:
        """Успешное изменение поля."""
        field_names = {
            "name": "Имя",
            "email": "Email", 
            "phone": "Телефон"
        }
        field_name = field_names.get(field, field)
        return (
            f"✅ <b>{field_name} изменено!</b>\n\n"
            f"Новое значение: <b>{new_value}</b>"
        )


# Алиас для удобства
messages = Messages()
