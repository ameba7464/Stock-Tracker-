"""Шаблоны сообщений с чистым минималистичным дизайном."""
from dataclasses import dataclass
from typing import Optional
from datetime import datetime


@dataclass
class UserStatus:
    """Статус пользователя для отображения."""
    has_api_key: bool = False
    has_table: bool = False
    last_update: Optional[datetime] = None


class Messages:
    """Централизованные шаблоны сообщений бота.
    
    Используем чистый минималистичный дизайн без громоздких Unicode-рамок.
    """
    
    # ═══════════════════════════════════════════════════
    # ПРИВЕТСТВИЯ
    # ═══════════════════════════════════════════════════
    
    @staticmethod
    def welcome_new_user() -> str:
        """Приветствие для нового пользователя."""
        return (
            "🎯 <b>Stock Tracker</b>\n\n"
            "Привет! Я помогу отслеживать остатки товаров "
            "на складах Wildberries.\n\n"
            "<b>Что умею:</b>\n"
            "• Автоматически обновлять данные\n"
            "• Собирать статистику по складам\n"
            "• Выгружать в Google Таблицу\n\n"
            "Давай начнём — это займёт 2 минуты.\n\n"
            "📝 <b>Шаг 1/3</b> — Как тебя зовут?"
        )
    
    @staticmethod
    def welcome_returning_user(name: str, status: UserStatus) -> str:
        """Приветствие для возвращающегося пользователя."""
        api_icon = "✅" if status.has_api_key else "❌"
        table_icon = "✅" if status.has_table else "⏳"
        
        update_text = ""
        if status.last_update:
            update_text = f"\n🕐 <i>Обновлено: {status.last_update.strftime('%d.%m в %H:%M')}</i>"
        
        return (
            f"🎯 <b>Stock Tracker</b>\n\n"
            f"👋 С возвращением, <b>{name}</b>!\n\n"
            f"{api_icon} API: {'Подключён' if status.has_api_key else 'Не подключён'}\n"
            f"{table_icon} Таблица: {'Готова' if status.has_table else 'Не создана'}"
            f"{update_text}\n\n"
            f"👇 Выберите действие:"
        )
    
    # ═══════════════════════════════════════════════════
    # РЕГИСТРАЦИЯ
    # ═══════════════════════════════════════════════════
    
    @staticmethod
    def registration_step_name(step: int = 1) -> str:
        """Шаг регистрации: запрос имени."""
        return (
            f"📝 <b>Регистрация</b> • Шаг {step}/3\n\n"
            "Как тебя зовут?\n\n"
            "<i>Введи имя или никнейм</i>"
        )
    
    @staticmethod
    def registration_step_email(name: str, step: int = 2) -> str:
        """Шаг регистрации: запрос email."""
        return (
            f"📝 <b>Регистрация</b> • Шаг {step}/3\n\n"
            f"Отлично, <b>{name}</b>!\n\n"
            "Теперь введи email:\n\n"
            "<i>На него придут уведомления</i>"
        )
    
    @staticmethod
    def registration_step_phone(step: int = 3) -> str:
        """Шаг регистрации: запрос телефона."""
        return (
            f"📝 <b>Регистрация</b> • Шаг {step}/3\n\n"
            "Последний шаг — номер телефона.\n\n"
            "📱 Нажми кнопку ниже или введи вручную\n\n"
            "<i>Формат: +79991234567</i>"
        )
    
    @staticmethod
    def registration_complete(name: str) -> str:
        """Регистрация завершена."""
        return (
            f"🎉 <b>Готово!</b>\n\n"
            f"Добро пожаловать, <b>{name}</b>!\n\n"
            "Теперь подключи API ключ Wildberries, "
            "чтобы получить свою таблицу."
        )
    
    # ═══════════════════════════════════════════════════
    # API КЛЮЧ
    # ═══════════════════════════════════════════════════
    
    @staticmethod
    def api_key_instructions() -> str:
        """Инструкция по получению API ключа."""
        return (
            "🔑 <b>Подключение Wildberries</b>\n\n"
            "Для работы нужен API ключ из личного кабинета.\n\n"
            "<b>Как получить:</b>\n"
            "1. Открой <a href='https://seller.wildberries.ru'>seller.wildberries.ru</a>\n"
            "2. Настройки → Доступ к API\n"
            "3. Создай ключ с правами:\n"
            "   • Аналитика\n"
            "   • Статистика\n"
            "4. Скопируй и отправь сюда\n\n"
            "📝 <i>Отправь ключ одним сообщением</i>"
        )
    
    @staticmethod
    def api_key_validating() -> str:
        """Проверка API ключа."""
        return (
            "⏳ <b>Проверяю ключ...</b>\n\n"
            "Подключаюсь к Wildberries API."
        )
    
    @staticmethod
    def api_key_success() -> str:
        """API ключ успешно сохранен."""
        return (
            "✅ <b>API ключ сохранён!</b>\n\n"
            "Теперь можешь создать свою таблицу.\n\n"
            "<i>💡 Данные обновляются автоматически в 00:01</i>"
        )
    
    @staticmethod
    def api_key_error() -> str:
        """Ошибка проверки API ключа."""
        return (
            "❌ <b>Не удалось проверить ключ</b>\n\n"
            "Возможные причины:\n"
            "• Неверный формат\n"
            "• Ключ деактивирован\n"
            "• Нет прав «Аналитика»\n\n"
            "Проверь ключ в ЛК WB и попробуй снова.\n\n"
            "<i>Для отмены: /start</i>"
        )
    
    # ═══════════════════════════════════════════════════
    # ТАБЛИЦА
    # ═══════════════════════════════════════════════════
    
    @staticmethod
    def table_generating() -> str:
        """Генерация таблицы."""
        return (
            "⏳ <b>Создаю таблицу...</b>\n\n"
            "• Получаю данные из WB\n"
            "• Формирую отчёт\n"
            "• Настраиваю доступ\n\n"
            "<i>Это займёт 1-2 минуты</i>"
        )
    
    @staticmethod
    def table_ready(sheet_url: str, is_new: bool = True) -> str:
        """Таблица готова."""
        action = "создана" if is_new else "обновлена"
        return (
            f"✅ <b>Таблица {action}!</b>\n\n"
            f"📊 <a href='{sheet_url}'>Открыть Google Таблицу</a>\n\n"
            "• Добавь в закладки\n"
            "• Обновляется в 00:01 МСК\n"
            "• Можно редактировать"
        )
    
    @staticmethod
    def table_error() -> str:
        """Ошибка создания таблицы."""
        return (
            "❌ <b>Не удалось создать таблицу</b>\n\n"
            "Возможные причины:\n"
            "• Проблема с Google API\n"
            "• Временные сбои WB\n\n"
            "Попробуй позже или обратись в поддержку."
        )
    
    # ═══════════════════════════════════════════════════
    # ИНФОРМАЦИЯ
    # ═══════════════════════════════════════════════════
    
    @staticmethod
    def about() -> str:
        """О сервисе."""
        return (
            "🎯 <b>Stock Tracker</b>\n"
            "<i>версия 1.0.0</i>\n\n"
            "Инструмент для селлеров Wildberries.\n\n"
            "<b>Возможности:</b>\n"
            "• Аналитика остатков на складах\n"
            "• Автоматическое обновление данных\n"
            "• Удобные Google Таблицы\n"
            "• Статистика по регионам\n\n"
            "👨‍💻 Разработано с ❤️"
        )
    
    @staticmethod
    def help_message() -> str:
        """Справка."""
        return (
            "💬 <b>Помощь</b>\n\n"
            "<b>Частые вопросы:</b>\n\n"
            "❓ <b>Где взять API ключ?</b>\n"
            "→ seller.wildberries.ru → Настройки → API\n\n"
            "❓ <b>Как часто обновляются данные?</b>\n"
            "→ Автоматически в 00:01 МСК\n\n"
            "❓ <b>Могу редактировать таблицу?</b>\n"
            "→ Да, это твоя копия\n\n"
            "📧 Вопросы → администратору"
        )
    
    # ═══════════════════════════════════════════════════
    # ОШИБКИ
    # ═══════════════════════════════════════════════════
    
    @staticmethod
    def error_invalid_name() -> str:
        """Ошибка: неверное имя."""
        return (
            "❌ Имя должно быть от 2 до 50 символов.\n\n"
            "Попробуй ещё раз:"
        )
    
    @staticmethod
    def error_invalid_email() -> str:
        """Ошибка: неверный email."""
        return (
            "❌ Проверь формат email.\n"
            "Например: name@mail.ru\n\n"
            "Попробуй ещё раз:"
        )
    
    @staticmethod
    def error_invalid_phone() -> str:
        """Ошибка: неверный телефон."""
        return (
            "❌ Введи 10-15 цифр.\n"
            "Например: +79991234567\n\n"
            "Попробуй ещё раз:"
        )
    
    @staticmethod
    def error_general() -> str:
        """Общая ошибка."""
        return (
            "❌ Произошла ошибка.\n\n"
            "Попробуй позже или напиши в поддержку.\n"
            "Команда /start вернёт в начало."
        )
    
    @staticmethod
    def error_api_key_invalid() -> str:
        """Ошибка: неверный формат API ключа."""
        return (
            "❌ Ключ слишком короткий.\n\n"
            "API ключ WB обычно длиннее 100 символов.\n"
            "Проверь и отправь снова."
        )


# Алиас для удобства
messages = Messages()
